**This main source folder is active, but the Dev3 Folder is not**
*Most code is taken from SimpleAuth and SimpleAuthHelper for Pocketmine*

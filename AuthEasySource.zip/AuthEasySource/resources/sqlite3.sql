CREATE TABLE players (
  name TEXT PRIMARY KEY,
  hash TEXT,
  registerdate INTEGER,
  logindate INTEGER,
  lastip TEXT
);
